package com.library.LibraryManagement.service;

public interface CachingService {

	public void evictAllCaches();

}
