package com.library.LibraryManagement.test;

import static org.junit.Assert.assertNotNull;
import org.junit.jupiter.api.ClassOrderer;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestClassOrder;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import com.library.LibraryManagement.domain.BorrowingRecord;
import com.library.LibraryManagement.repository.BorrowingRecordRepository;
import com.library.LibraryManagement.service.BookManagementService;
import com.library.LibraryManagement.service.BorrowingRecordService;
import com.library.LibraryManagement.service.CachingService;
import com.library.LibraryManagement.service.PatronManagementService;

@RunWith(SpringRunner.class)
@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@TestClassOrder(ClassOrderer.OrderAnnotation.class)
@Order(3)
public class BorrowingRecordTest {

	@Autowired
	BorrowingRecordService borrowService;

	@Autowired
	BorrowingRecordRepository bookRepo;

	@Autowired
	BookManagementService bookService;

	@Autowired
	PatronManagementService patronService;
	
	@Autowired
	CachingService cacheService;

	@Test
	@Order(1)
	public void borrowBook() throws Exception {
		BorrowingRecord record = new BorrowingRecord();
		cacheService.evictAllCaches();
		record = borrowService.borrowBook(1L,1L);
		assertNotNull(record.getBorrowingId());
	}

	@Test
	@Order(2)
	public void recordBookReturn() throws Exception {
		BorrowingRecord returnRecord = new BorrowingRecord();
		cacheService.evictAllCaches();
		returnRecord = borrowService.recordBookReturn(1L,1L);
		assertNotNull(returnRecord.getReturnDate());
	}

}
