package com.library.LibraryManagement.service.impl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.library.LibraryManagement.domain.Patron;
import com.library.LibraryManagement.repository.PatronManagementRepository;
import com.library.LibraryManagement.service.CachingService;
import com.library.LibraryManagement.service.PatronManagementService;

@Service("PatronManagementService")
public class PatronManagementServiceImpl implements PatronManagementService {
	
	@Autowired
	PatronManagementRepository patronManagementRepo;
	
	@Autowired
	CachingService cacheService;
	
	@Override
	@Transactional
	@Cacheable("patrons")
	public List<Patron> fetchAllPatrons() throws Exception {
		return patronManagementRepo.findAll();
	}	
	
	@Override
	@Transactional
	public Patron addPatron(Patron patron) throws Exception {
		cacheService.evictAllCaches();
		return patronManagementRepo.save(patron);
	}
	
	@Override
	@Transactional
	@Cacheable("patronById")
	public Optional<Patron> getPatronDetailsById(Long id) throws Exception {
		return patronManagementRepo.findById(id);
	}

	@Override
	@Transactional
	public Patron updatePatron(Patron patron,Long id) throws Exception {
		cacheService.evictAllCaches();
		Patron getPatron = patronManagementRepo.findById(id).get();
		if(patron.getContactInfo() != null) {
		    getPatron.setContactInfo(patron.getContactInfo());
		}
		if(patron.getName() != null) {
		    getPatron.setName(patron.getName());
		}
		return patronManagementRepo.save(getPatron);
	}
	
	@Override
	@Transactional
	public void deletePatron(Long id) throws Exception {
		cacheService.evictAllCaches();
		Patron patron = patronManagementRepo.findById(id).get();
		patronManagementRepo.delete(patron);
	}
	
}