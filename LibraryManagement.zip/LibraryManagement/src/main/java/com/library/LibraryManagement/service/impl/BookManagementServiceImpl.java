package com.library.LibraryManagement.service.impl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.library.LibraryManagement.domain.Book;
import com.library.LibraryManagement.repository.BookManagementRepository;
import com.library.LibraryManagement.service.BookManagementService;
import com.library.LibraryManagement.service.CachingService;

@Service("BookManagementService")
public class BookManagementServiceImpl implements BookManagementService {
	
	@Autowired
	BookManagementRepository bookManagementRepo;
	
	@Autowired
	CachingService cacheService;
	
	@Override
	@Transactional
	@Cacheable("books")
	public List<Book> fetchAllBooks() throws Exception {
		return bookManagementRepo.findAll();
	}	
	
	@Override
	@Transactional
	public Book addBook(Book book) throws Exception {
		cacheService.evictAllCaches();
		return bookManagementRepo.save(book);
	}
	
	@Override
	@Transactional
	@Cacheable("bookById")
	public Optional<Book> getBookDetailsById(Long id) throws Exception {
		return bookManagementRepo.findById(id);
	}

	@Override
	@Transactional
	public Book updateBook(Book book,Long id) throws Exception {
		cacheService.evictAllCaches();
		Book getBook = bookManagementRepo.findById(id).get();
		if(book.getTitle() != null) {
			getBook.setTitle(book.getTitle());
		}
		if(book.getAuthor() != null) {
			getBook.setAuthor(book.getAuthor());
		}
		if(book.getPublicationYear() != 0) {
			getBook.setPublicationYear(book.getPublicationYear());
		}
		if(book.getIsbn() != null) {
			getBook.setIsbn(book.getIsbn());
		}
		return bookManagementRepo.save(getBook);
	}

	@Override
	@Transactional
	public void deleteBook(Long id) throws Exception {
		cacheService.evictAllCaches();
		Book book = bookManagementRepo.findById(id).get();
		bookManagementRepo.delete(book);
	}
}