package com.library.LibraryManagement.service;

import com.library.LibraryManagement.domain.BorrowingRecord;

public interface BorrowingRecordService {

	public BorrowingRecord borrowBook(Long bookId, Long patronId) throws Exception;
	public BorrowingRecord recordBookReturn(Long bookId, Long patronId) throws Exception;
	
}