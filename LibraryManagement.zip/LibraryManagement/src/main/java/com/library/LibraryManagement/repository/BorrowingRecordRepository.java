package com.library.LibraryManagement.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.library.LibraryManagement.domain.Book;
import com.library.LibraryManagement.domain.BorrowingRecord;
import com.library.LibraryManagement.domain.Patron;

public interface BorrowingRecordRepository extends JpaRepository<BorrowingRecord,Long> {

	Optional<BorrowingRecord> findByBookAndPatron(Book book, Patron patron);
	Optional<BorrowingRecord> findByBookId(Long bookId);
	Optional<BorrowingRecord> findByPatronId(Long id);
	
}