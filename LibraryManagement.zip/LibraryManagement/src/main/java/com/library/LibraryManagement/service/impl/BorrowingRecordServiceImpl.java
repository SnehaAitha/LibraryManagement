package com.library.LibraryManagement.service.impl;

import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.library.LibraryManagement.domain.Book;
import com.library.LibraryManagement.domain.BorrowingRecord;
import com.library.LibraryManagement.domain.Patron;
import com.library.LibraryManagement.repository.BorrowingRecordRepository;
import com.library.LibraryManagement.service.BookManagementService;
import com.library.LibraryManagement.service.BorrowingRecordService;
import com.library.LibraryManagement.service.CachingService;
import com.library.LibraryManagement.service.PatronManagementService;

@Service("BorrowingRecordService")
public class BorrowingRecordServiceImpl implements BorrowingRecordService {

	@Autowired
	BorrowingRecordRepository borrowingRecordRepo;

	@Autowired
	BookManagementService bookService;

	@Autowired
	PatronManagementService patronService;
	
	@Autowired
	CachingService cacheService;

	@Override
	@Transactional
	public BorrowingRecord borrowBook(Long bookId, Long patronId) throws Exception {
		cacheService.evictAllCaches();
		BorrowingRecord borrowingRecord = new BorrowingRecord();
		Patron patron = patronService.getPatronDetailsById(patronId).get();
		Book book = bookService.getBookDetailsById(bookId).get();
		borrowingRecord.setPatron(patron);
		borrowingRecord.setBook(book);
		borrowingRecord.setBorrowingDate(new Date());
		patron.addBorrowingRecord(borrowingRecord);
		book.addBorrowingRecord(borrowingRecord);
		return borrowingRecordRepo.save(borrowingRecord);
	}

	@Override
	@Transactional
	public BorrowingRecord recordBookReturn(Long bookId, Long patronId) throws Exception {
		cacheService.evictAllCaches();
		Patron patron = patronService.getPatronDetailsById(patronId).get();
		Book book = bookService.getBookDetailsById(bookId).get();
		BorrowingRecord returnRecord = borrowingRecordRepo.findByBookAndPatron(book,patron).get();
		returnRecord.setPatron(patron);
		returnRecord.setBook(book);
		returnRecord.setReturnDate(new Date());
		returnRecord = borrowingRecordRepo.save(returnRecord);
		patron.addBorrowingRecord(returnRecord);
		book.addBorrowingRecord(returnRecord);
		return borrowingRecordRepo.save(returnRecord);
	}


}